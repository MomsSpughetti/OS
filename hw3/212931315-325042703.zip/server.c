#include "segel.h"
#include "request.h"
#include "Queue.h"
#include "stdbool.h"
// 
// server.c: A very, very simple web server
//
// To run:
//  ./server <portnum (above 2000)>
//
// Repeatedly handles HTTP requests sent to this port number.
// Most of the work is done within routines written in request.c
//
// HW3: Parse the new arguments too




//Global Vars
pthread_mutex_t global;
pthread_cond_t waitingCond, fullCond, emptyCond;
int waitingQueueSize = 0,workingQueueSize =0;
Queue* waitingQueue = NULL;
Queue* workingQueue = NULL;


#define MICRO_TO_SEC 1000000
void calcDiff(requestInfo* request){
    long t1 =  request->startingTime.tv_sec*MICRO_TO_SEC +  request->startingTime.tv_usec;
    long t2  =  request->arrivingTime.tv_sec*MICRO_TO_SEC +  request->arrivingTime.tv_usec;
    long delta = t1-t2;

    request->startingTime.tv_sec = delta/MICRO_TO_SEC;
    request->startingTime.tv_usec = delta % MICRO_TO_SEC;
}

int cmp(const void* x, const void* y){
    if(*(int*)x > *(int*)y){
        return 1;
    }
    return -1;
}

int getHalf(int x){
    int a = ((x%2) == 0) ? 0 : 1;
    return x/2 +a;
}

void dropRandom(){
    int half = getHalf(waitingQueueSize);
    int *toDrop =(int*)malloc(sizeof(int)*half);
    bool *used = (bool*)malloc(sizeof(bool)*(waitingQueueSize));
    for(int i=0;i<waitingQueueSize;++i){
        used[i]=false;
    }
    for (int i = 0; i < half; i++){
        toDrop[i] = rand() % waitingQueueSize;
        while(used[toDrop[i]])
            toDrop[i] = rand() % waitingQueueSize;
        used[toDrop[i]] = true;
    }
    free(used);
    qsort(toDrop,half,sizeof(int),cmp);//Note that using qsort in O(nlogn) in average does not affect the worst case.
    int waitingQueueIndex = 0;
    int toDropIndex = 0;
    requestInfo request;
    //delete half of the workingQueue size
    Node *curr = waitingQueue->head,*temp;
    while (toDropIndex < half){
        if(toDrop[toDropIndex] == waitingQueueIndex){
            temp = curr;
            curr= curr->next;
            request = removeNode(waitingQueue,temp);
            Close(request.fd);
            toDropIndex++;
            waitingQueueSize--;
        }else{
            curr = curr->next;
        }
        waitingQueueIndex++;
    }//update workingQueue size
    free(toDrop);
}

void* requestHandlerWorker(void* args){
    threadInfo* thread = (threadInfo*)args;
    requestInfo request;
    while(1){
        pthread_mutex_lock(&global);
        while(waitingQueueSize == 0)  pthread_cond_wait(&waitingCond,&global);
        request = pop(waitingQueue);
        waitingQueueSize--;
        struct timezone t;
        gettimeofday(&request.startingTime,&t);
        calcDiff(&request);
        request.thread = thread;
        push(workingQueue,request);
        workingQueueSize++;
        pthread_mutex_unlock(&global);
        requestHandle(request);
        pthread_mutex_lock(&global);
        removeNode(workingQueue,findNode(workingQueue,request));
        workingQueueSize--;
        pthread_cond_signal(&fullCond);        
        Close(request.fd);
        if(waitingQueueSize + workingQueueSize== 0) pthread_cond_signal(&emptyCond);
        pthread_mutex_unlock(&global);
    }
    return NULL;
}

void addRequest(int* queueSizePtr,char* policy, int maxQueueSize, requestInfo newRequest) {
    pthread_mutex_lock(&global);
    bool ignore = false;
    int queueSize = *queueSizePtr;
    if(strcmp(policy,"block") == 0){
        while(waitingQueueSize + workingQueueSize == queueSize) {
            pthread_cond_wait(&fullCond, &global);
        }
    }
    if(strcmp(policy,"dt") == 0){
        if(waitingQueueSize + workingQueueSize == queueSize) {
            ignore = true;
        }
    }
    if(strcmp(policy,"dh") == 0){
        if(waitingQueueSize + workingQueueSize == queueSize){
            if(waitingQueueSize != 0) {
                requestInfo request = pop(waitingQueue);
                Close(request.fd);
                push(waitingQueue,newRequest);
                pthread_mutex_unlock(&global);
                return;
            }else{
                ignore = true;
            }
        }
    }
    if(strcmp(policy,"bf") == 0){
        if(waitingQueueSize + workingQueueSize == queueSize) {
            ignore = true;
            while(waitingQueueSize + workingQueueSize != 0){
                pthread_cond_wait(&emptyCond, &global);
            }
        }
    }
    if(strcmp(policy,"dynamic") == 0){
        if(waitingQueueSize + workingQueueSize == queueSize) {
            ignore = true;
            if (queueSize < maxQueueSize) (*queueSizePtr)++;
        }
    }
    if(strcmp(policy,"random") == 0) {
        if((waitingQueueSize + workingQueueSize == queueSize)){
            if(waitingQueueSize != 0){
                dropRandom();
            }else{
                ignore = true;
            }
        }
    }
    if(!ignore) {
        push(waitingQueue, newRequest);
        waitingQueueSize++;
        pthread_cond_signal(&waitingCond);
    }else{
        Close(newRequest.fd);
    }
    pthread_mutex_unlock(&global);
}



void getargs(int *port, int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        exit(1);
    }
    *port = atoi(argv[1]);
}




int main(int argc, char *argv[])
{
    int listenfd, connfd, port, clientlen;
    struct sockaddr_in clientaddr;
    //./server [portnum] [threads] [queue_size] [schedalg] [max_size(optional)]
    //Preparing Arguments.
    pthread_mutex_init(&global, NULL);
    pthread_cond_init(&waitingCond,NULL);
    pthread_cond_init(&fullCond,NULL);
    pthread_cond_init(&emptyCond,NULL);
    getargs(&port, argc, argv);
    workingQueue = initQueue();
    waitingQueue = initQueue();
    int threadsNum = atoi(argv[2]);
    int queueSize = atoi(argv[3]);
    char* policy = argv[4];
    int queueMaxSize =(strcmp(policy,"dynamic") == 0) ? atoi(argv[5]): queueSize;
    pthread_t* threadsArr = (pthread_t*)malloc(threadsNum*sizeof(pthread_t));
    //Spawning Threads.
    threadInfo* threadInfoArr =(threadInfo*)malloc(threadsNum*sizeof(threadInfo));
    for(int i=0;i<threadsNum;++i){
        threadInfoArr[i].thisThread = &threadsArr[i];
        threadInfoArr[i].id= i;
        threadInfoArr[i].count = 0;
        threadInfoArr[i].dynamicCount = 0;
        threadInfoArr[i].staticCount = 0;
        pthread_create(&threadsArr[i],NULL,requestHandlerWorker,(void*)&threadInfoArr[i]);
    }

    //Request Accepting
    listenfd = Open_listenfd(port);
    if(listenfd == -1){
            destroyQueue(waitingQueue);
            destroyQueue(workingQueue);
            free(threadsArr);
            free(threadInfoArr);
            pthread_mutex_destroy(&global);
            return 0;
    }
    while(1) {
        clientlen = sizeof(clientaddr);
        connfd = Accept(listenfd, (SA *) &clientaddr, (socklen_t *) &clientlen);//Connceting to the next client.
        requestInfo newRequest;
        struct timezone t;
        gettimeofday(&newRequest.arrivingTime,&t);
        newRequest.fd =connfd;
        addRequest(&queueSize,policy,queueMaxSize, newRequest);
    }
    destroyQueue(waitingQueue);
    destroyQueue(workingQueue);
    free(threadsArr);
    free(threadInfoArr);
    pthread_mutex_destroy(&global);
    return 0;
}


    


 
