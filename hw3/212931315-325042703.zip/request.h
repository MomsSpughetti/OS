#ifndef __REQUEST_H__
#include "Queue.h"

void requestHandle(requestInfo request);

#endif
