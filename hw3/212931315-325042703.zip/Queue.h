//
// Created by moham on 15/06/2023.
//
#include "segel.h"
#ifndef HW3_QUEUE_H
#define HW3_QUEUE_H

typedef enum QueueStatus{FAILED,SUCCESS,MALLOC_FAIL,NULL_ARG} QueueStatus;

typedef struct threadInfo{
    pthread_t* thisThread;
    int id;
    int count;
    int staticCount;
    int dynamicCount;
}threadInfo;



typedef struct requestInfo{
    struct threadInfo* thread;
    int fd;
    struct timeval arrivingTime;
    struct timeval startingTime;
}requestInfo;


typedef requestInfo T;

typedef struct Node{
    T data;
    struct Node* next;
    struct Node* prev;
}Node;

typedef struct Queue{
    int size;
    Node* head;
    Node* last;
}Queue;

Queue* initQueue();
QueueStatus push(Queue* queue,T val);
T pop(Queue* queue);
QueueStatus destroyQueue(Queue* queue);
Node* findNode(Queue* queue, T data);
T removeNode(Queue* queue,Node* node);
// T pop(Queue* queue,pthread_cond_t* c, pthread_mutex_t* m, int* condVar, pthread_cond_t* empty, pthread_cond_t* full);
// QueueStatus push(Queue* queue,T val,pthread_cond_t* c, pthread_mutex_t* m, int* condVar);
// QueueStatus deleteNode(Queue* queue,T fd,pthread_cond_t* c, pthread_mutex_t* m, int* condVar,pthread_cond_t* empty, pthread_cond_t* full);
#endif //HW3_QUEUE_H
